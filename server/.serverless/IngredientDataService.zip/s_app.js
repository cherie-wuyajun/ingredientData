var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'smzx199477',
applicationName: 'heali-app',
appUid: 'V28jtY5L1lcxC3xgsS',
tenantUid: 'vPyWBtWvH7H8BWhczf',
deploymentUid: '6b45ceb8-6e06-4585-8c59-03a2742afcd5',
serviceName: 'IngredientDataService',
stageName: 'dev',
pluginVersion: '3.0.0'})
const handlerWrapperArgs = { functionName: 'IngredientDataService-dev-app', timeout: 6}
try {
  const userHandler = require('./app.js')
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
